from flask import Flask, url_for


app = Flask(__name__)

@app.route("/")
def root():
    return "<h1>Миссия Колонизация Марса</h1>"


@app.route("/index")
def index():
    return "И на Марсе будут яблони цвести!"


@app.route("/promotion")
def promotion():
    contents = """Человечество вырастает из детства.<br>
Человечеству мала одна планета.<br>
Мы сделаем обитаемыми безжизненные пока планеты.<br>
И начнем с Марса!<br>
Присоединяйся!<br>"""
    return contents


@app.route("/image_mars")
def image_mars():
    content = """
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Привет, Марс!</title>
    </head>
    <body>
        <h1>Жди нас, Марс!</h1>
        <img src="https://i.ibb.co/f4XDB2c/mars.png" alt="Фото Марса украли инопланетяне"
        height=500 width=500>
        <br>Вот она какая, красная планета.
    </body>
</html>"""
    return content


@app.route("/promotion_image")
def promotion_image():
    marketing_list_text = ['Человечество вырастает из детства.',
                           'Человечеству мала одна планета.',
                           'Мы сделаем обитаемыми безжизненные пока планеты.',
                           'И начнем с Марса!',
                           'Присоединяйся!']
    colors = ("primary", "danger", "warning", "dark", "success")
    format_list_text = [f'<div class="alert alert-{color}" role="alert">{elem}</div>' for
                        elem, color in zip(marketing_list_text, colors)]
    return f"""
            <!doctype html>
            <html>
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
                    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
                    crossorigin="anonymous">
                    <link rel="stylesheet" href="{url_for("static", filename="css/style.css")}">
                    <title>Привет, Марс!</title>
                </head>
                <body>
                    <h1>Жди нас, Марс!</h1>
                    <img src="{url_for("static", filename="img/mars.png")}"
                    alt="Фото Марса украл НЛО"
                    height=500 width=500>
                    {'\n'.join(format_list_text)}
                </body>
            </html>"""


@app.route("/choice/<planet_name>")
def selection_options(planet_name):
    list_text = ['На ней много необходимых ресурсов;',
                 'На ней есть вода и атмосфера;',
                 'На ней есть небольшое магнитное поле;',
                 'Она красивая;',
                 'И ОНА МНЕ НРАВИТЬСЯ!']
    colors = ("primary", "danger", "warning", "dark", "success")
    format_list_text = [f'<div class="alert alert-{color}" role="alert">{elem}</div>' for
                        elem, color in zip(list_text, colors)]
    return f"""
            <!doctype html>
            <html>
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
                    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
                    crossorigin="anonymous">
                    <title>Варианты выбора</title>
                </head>
                <body>
                    <h1>Моё предложенин: {planet_name}</h1>
                    <h3>Эта планета близка к Земле;</h3>
                    {'\n'.join(format_list_text)}
                </body>
            </html>"""


@app.route("/results/<nickname>/<int:level>/<float:rating>")
def results(nickname, level, rating):
    list_text = [
        f'Поздравляем! Ваш рейтинг после {level} этапа отбора',
        'Желаем удачи!'
    ]
    colors = ("success", "warning")
    format_list_text = [f'<div class="alert alert-{color}" role="alert">{elem}</div>' for
                        elem, color in zip(list_text, colors)]
    return f"""
            <!doctype html>
            <html>
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
                    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
                    crossorigin="anonymous">
                    <title>Варианты выбора</title>
                </head>
                <body>
                    <h1>Результаты отбора</h1>
                    <h2>Претендента на участие в миссии {nickname}:</h2>
                    {format_list_text[0]}
                    <h3>составляет {rating}!</h3>
                    {format_list_text[1]}
                </body>
            </html>"""


@app.route("/carousel")
def carousel():
    return """<!DOCTYPE html>
                <html>
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
                        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
                    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
                        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
                        crossorigin="anonymous"></script>
                    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
                        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
                        crossorigin="anonymous"></script>
                    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
                        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
                        crossorigin="anonymous"></script>
                    <link rel="stylesheet" href="static/css/style.css">
                    <title>Пейзажи Марса</title>
                </head>
                <body>
                    <header class="centered">
                        <h1>Пейзажи Марса</h1>
                    </header>
                    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="static/img/slides/slide1.jpg" class="d-block w-100" alt="Slide 1">
                            </div>
                            <div class="carousel-item">
                                <img src="static/img/slides/slide2.jpg" class="d-block w-100" alt="Slide 2">
                            </div>
                            <div class="carousel-item">
                                <img src="static/img/slides/slide3.jpg" class="d-block w-100" alt="Slide 3">
                            </div>
                            <div class="carousel-item">
                                <img src="static/img/slides/slide4.jpg" class="d-block w-100" alt="Slide 4">
                            </div>
                            <div class="carousel-item">
                                <img src="static/img/slides/slide5.jpg" class="d-block w-100" alt="Slide 5">
                            </div>
                            <div class="carousel-item">
                                <img src="static/img/slides/slide6.jpg" class="d-block w-100" alt="Slide 6">
                            </div>
                        </div>
                    </div>
                </body>
                </html>
                """


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
