from flask import Flask, render_template


app = Flask(__name__)

@app.route("/list_prof/<type>")
def profession_list(type):
    if type not in ["ul", "ol"]:
        return render_template("invalid.html")

    profession_list = ["инженер по терраформированию", "экзобиолог", 
                       "врач", "специалист по радиацинной защите", "строитель", 
                       "астрогеолог", "инженер-исследователь", "штурман", "метеоролог", 
                       "пилот дронов", "гляциолог", "климатолог", "инженер жизнеобеспечения", 
                       "оператор марсохода", "пилот", "киберинженер"]

    return render_template("base.html", type_=type,
                           profession_list=profession_list)


if __name__ == "__main__":
    app.run(port=8080, host="127.0.0.1")
