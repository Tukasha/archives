import datetime

from flask import Flask, render_template
from data.db_session import global_init, create_session
from data.users import User
from data.jobs import Job

app = Flask(__name__)
app.config['SECRET_KEY'] = 'super_secret_key'


@app.route("/")
def index():
    db_sess = create_session()
    data = []

    for job in db_sess.query(Job).all():
        team_leader = db_sess.query(User).filter(User.id == job.team_leader).first()
        representation = f"{team_leader.surname} {team_leader.name}"
        data.append((job,
                     representation))

    return render_template("jobs.html", jobs=data)


def main():
    global_init("db/mars_explorer.db")
    app.run()


if __name__ == '__main__':
    user1 = User()
    user1.surname = "Scott"
    user1.name = "Ridley"

    user2 = User()
    user2.surname = "Washington"
    user2.name = "George"

    user3 = User()
    user3.surname = "Smith"
    user3.name = "Will"

    user4 = User()
    user4.surname = "Wright"
    user4.name = "Apollo"

    job = Job()
    job.team_leader = 1
    job.job = "deployment of residental modules 1 and 2"
    job.work_size = 15
    job.collaborators = "2, 3"
    job.start_date = datetime.datetime.now()
    job.is_finished = False

    db_sess = create_session()

    db_sess.add_all([user1, user2, user3, user4, job])

    db_sess.commit()

    main()

