from flask import Flask, url_for


app = Flask(__name__)

@app.route("/")
def root():
    return "<h1>Миссия Колонизация Марса</h1>"


@app.route("/index")
def index():
    return "И на Марсе будут яблони цвести!"


@app.route("/promotion")
def promotion():
    contents = """Человечество вырастает из детства.<br>
Человечеству мала одна планета.<br>
Мы сделаем обитаемыми безжизненные пока планеты.<br>
И начнем с Марса!<br>
Присоединяйся!<br>"""
    return contents


@app.route("/image_mars")
def image_mars():
    content = """
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Привет, Марс!</title>
    </head>
    <body>
        <h1>Жди нас, Марс!</h1>
        <img src="https://i.ibb.co/f4XDB2c/mars.png" alt="Фото Марса украли инопланетяне"
        height=500 width=500>
        <br>Вот она какая, красная планета.
    </body>
</html>"""
    return content


@app.route("/promotion_image")
def promotion_image():
    marketing_list_text = ["Человечество вырастает из детства.",
                           "Человечеству мала одна планета.",
                           "Мы сделаем обитаемыми безжизненные пока планеты.",
                           "И начнем с Марса!",
                           "Присоединяйся!"]
    colors = ("primary", "danger", "warning", "dark", "success")
    format_list_text = [f"<div class='alert alert-{color}' role='alert'>{elem}</div>" for elem, color in zip(marketing_list_text, colors)]
    return f"""
            <!doctype html>
            <html>
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
                    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
                    crossorigin="anonymous">
                    <link rel="stylesheet" href="{url_for("static", filename="css/style.css")}">
                    <title>Привет, Марс!</title>
                </head>
                <body>
                    <h1>Жди нас, Марс!</h1>
                    <img src="{url_for("static", filename="img/mars.png")}"
                    alt="Фото Марса украл НЛО"
                    height=500 width=500>
                    {"\n".join(format_list_text)}
                </body>
            </html>"""


@app.route("/choice/<planet_name>")
def selection_options(planet_name):
    list_text = ["На ней много необходимых ресурсов;",
                 "На ней есть вода и атмосфера;",
                 "На ней есть небольшое магнитное поле;",
                 "Она красивая;",
                 "И ОНА МНЕ НРАВИТЬСЯ!"]
    colors = ("primary", "danger", "warning", "dark", "success")
    format_list_text = [f"<div class='alert alert-{color}' role='alert'>{elem}</div>" for elem, color in zip(list_text, colors)]
    return f"""
            <!doctype html>
            <html>
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
                    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
                    crossorigin="anonymous">
                    <title>Варианты выбора</title>
                </head>
                <body>
                    <h1>Моё предложение: {planet_name}</h1>
                    <h3>Эта планета близка к Земле;</h3>
                    {"\n".join(format_list_text)}
                </body>
            </html>"""


if __name__ == "__main__":
    app.run(port=8080, host="127.0.0.1")
